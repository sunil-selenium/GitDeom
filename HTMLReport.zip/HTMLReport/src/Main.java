import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.model.SystemProperties;

public class Main {
    private static ExtentReports extent;

    public static void main(String[] args) {
    	try
    	{
    	System.out.println("Start");
          extent = new ExtentReports("D:\\Automation\\Selenium\\NMWJ\\src\\Output\\HTML_Logs\\NMWJ_2688_11_2015_Logs\\NMWJ_2116_11_2015_Logs4.html", false);
        // creates a toggle for the given test, adds all log events under it    
        ExtentTest test = extent.startTest("My First Test", "Sample description");
        // log(LogStatus, details)
      //  test.log(LogStatus.INFO, "This step shows usage of log(logStatus, details)");
        test.log(LogStatus.PASS, "This step  Pass");
        test.log(LogStatus.PASS, "This step  Pass");
        test.log(LogStatus.PASS, "This step  Pass");
        test.log(LogStatus.PASS, "This step  Pass");
      //extent.addSystemInfo("OS",System.getProperty("os.name"));
      //extent.addSystemInfo("OS",System.getProperty("os.version"));
        // report with snapshot
        //String img = test.addScreenCapture("D:\\Automation\\Selenium\\NMWJ\\src\\Output\\Screenshots\\GSP_721_06_10_2015_10_49_32_AM.png");
        //test.log(LogStatus.FAIL, "Image", "Image example: " + img);
        
        // end test
        extent.endTest(test);
                // calling flush writes everything to the log file
        extent.flush();
        //Stop
        System.out.println("Stop");
    	}
    	catch(Exception e)
    	{
    		 System .out.println("Error :"+e);
    	}    	
    }
}
